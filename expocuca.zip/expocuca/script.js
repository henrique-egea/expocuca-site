const values = [62, 25, 87, 41, 73, 18, 54, 92];
const bars = document.getElementById('bars');
const sortButton = document.getElementById('sortButton');
const shuffleButton = document.getElementById('shuffleButton');
const status = document.getElementById('status');
const comparison = document.getElementById('comparison');
let sorting = false;

function render(active = [], sorted = []) {
  bars.innerHTML = '';
  values.forEach((value, index) => {
    const bar = document.createElement('div');
    bar.className = `bar ${active.includes(index) ? 'active' : ''} ${sorted.includes(index) ? 'sorted' : ''}`;
    bar.style.height = `${value * 2.1}px`;
    bar.dataset.value = value;
    bars.appendChild(bar);
  });
}

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function bubbleSort() {
  if (sorting) return;
  sorting = true;
  sortButton.disabled = true;
  shuffleButton.disabled = true;
  let count = 0;
  status.textContent = 'ordenando…';
  for (let end = values.length - 1; end > 0; end--) {
    for (let i = 0; i < end; i++) {
      count++;
      comparison.textContent = `${count} ${count === 1 ? 'comparação' : 'comparações'}`;
      render([i, i + 1], Array.from({ length: values.length - end - 1 }, (_, n) => values.length - 1 - n));
      await wait(250);
      if (values[i] > values[i + 1]) [values[i], values[i + 1]] = [values[i + 1], values[i]];
      render([i, i + 1], Array.from({ length: values.length - end - 1 }, (_, n) => values.length - 1 - n));
      await wait(100);
    }
  }
  render([], values.map((_, i) => i));
  status.textContent = 'lista ordenada ✓';
  sortButton.disabled = false;
  shuffleButton.disabled = false;
  sorting = false;
}

function shuffle() {
  if (sorting) return;
  for (let i = values.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [values[i], values[j]] = [values[j], values[i]];
  }
  status.textContent = 'pronto para começar';
  comparison.textContent = '0 comparações';
  render();
}

sortButton.addEventListener('click', bubbleSort);
shuffleButton.addEventListener('click', shuffle);
render();

const observer = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); }
}), { threshold: .14 });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

document.querySelectorAll('.hero-actions a[href^="#"]').forEach(link => {
  link.addEventListener('click', (event) => {
    const target = document.querySelector(link.getAttribute('href'));
    if (!target) return;
    event.preventDefault();
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

document.querySelectorAll('.quiz-options button').forEach(button => {
  button.addEventListener('click', () => {
    const feedback = document.getElementById('quiz-feedback');
    document.querySelectorAll('.quiz-options button').forEach(item => item.classList.remove('selected', 'wrong'));
    if (button.dataset.answer === 'right') {
      button.classList.add('selected');
      feedback.textContent = 'Acertou! Antes de programar, organize o problema em partes menores.';
    } else {
      button.classList.add('wrong');
      feedback.textContent = 'Quase! Toda boa solução começa entendendo o problema.';
    }
  });
});
